package net.sourceforge.pmd.ast;



public interface CanSuppressWarnings {
}
