package net.sourceforge.pmd.ast;

/**
 * Marker interface for root nodes of the AST of compilation units in source files.
 *
 * @author pieter_van_raemdonck - Application Engineers NV/SA - www.ae.be
 */
public interface CompilationUnit {

}
