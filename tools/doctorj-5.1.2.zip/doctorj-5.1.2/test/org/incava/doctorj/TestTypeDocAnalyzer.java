package org.incava.doctorj;

import junit.framework.TestCase;


public class TestTypeDocAnalyzer extends Tester
{
    public TestTypeDocAnalyzer(String name)
    {
        super(name);
    }

    public void testNothing()
    {
        // this method exists just to keep JUnit from complaining.
    }

}
