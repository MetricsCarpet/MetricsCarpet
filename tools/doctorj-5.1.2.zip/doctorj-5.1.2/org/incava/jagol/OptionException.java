package org.incava.jagol;

import java.io.*;
import java.util.*;

public class OptionException extends Exception
{
    public OptionException(String msg)
    {
        super(msg);
    }

}
