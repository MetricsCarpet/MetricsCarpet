public class AnEnum {
  /**
   * test
   */
  public int aMethod() {
    return ordinal() * 100;
  }
}
