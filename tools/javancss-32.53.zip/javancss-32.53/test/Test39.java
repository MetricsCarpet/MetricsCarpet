
// empty statements ;
package javancss.text;

import java.util.*;

public class Test39 {;
;;
    public Test39() {;
    ;;
    };
;;
    public void run() {;;
    ;;
    };;
};;
;;
