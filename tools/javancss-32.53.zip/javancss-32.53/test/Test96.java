public abstract class  Test96 {
    public void removeAWTEventListener(AWTEventListener listener) {
        assert calls[i] >= 0: "Negative Listeners count";
    }
}

