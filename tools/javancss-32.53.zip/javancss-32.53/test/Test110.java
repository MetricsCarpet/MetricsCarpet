public class Test110<T> implements Iterator<SomeInfo<OtherIterator<T>>>
{
}
