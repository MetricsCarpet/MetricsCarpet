package ham.cham;

import java.lang.annotation.*;

/**
 * bla bla
 *
 * @author  Nope Hope
 * @version 1.4, 06/10/04
 * @since 1.5
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface Deprecated {
}
