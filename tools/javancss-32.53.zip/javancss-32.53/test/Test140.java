/**
 * 
 * @author
 *
 */
public class TestJavadocAnnotation extends TestSuperClass{

	/**
	 * 
	 */
	@Override
	public void testMethod() {
		
	}
}
