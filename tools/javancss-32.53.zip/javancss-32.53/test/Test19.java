package test;

public class Test19 {
    public void foo(String[] asArgs_, Controller pController_) {
        int i;
    }

    public Jacob(Controller pController_, String[] asArgs_) {
        super();
    }

    public void foo2(int pController_, String[] asArgs_) {
        int i;
    }

    public static void main(String asArgs_[]) {
        System.exit(0);
    }
}
