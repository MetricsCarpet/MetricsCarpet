public class Test114
{
    public Javancss(String[] asArgs_, String sRcsHeader_) {
        while( enum.hasMoreElements() )
        {
        }
    }
}
