public class MyClass {

@Deprecated
interface MyInterface { void doStuff(); }

}
